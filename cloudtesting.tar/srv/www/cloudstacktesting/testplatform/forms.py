from django.forms.fields import DateField
from django.contrib.admin import widgets 
from django import forms
from testplatform.clouddb import Zones, ServiceOfferings, DiskOfferings, PublicTemplates
from testplatform.models import CloudStackIpAddress

class TestCriteriaForm(forms.Form):

    NUMBEROFVMS = (
        ("1", "1"),
        ("2", "2"),
        ("3", "3"),
        ("4", "4"),
        ("5", "5"),)

    # Test name and number of accounts to loop through

    testname = forms.CharField(label='Test Name', required=True)
    csmip = forms.ModelChoiceField(queryset=CloudStackIpAddress.objects.all(), label='Cloudstack management server IP to test')

    numberofaccs = forms.ChoiceField(choices=NUMBEROFVMS, label='Number of accounts to test', required=False)

    # Deploy a VM

    serviceoffering = forms.ChoiceField(choices=ServiceOfferings(), label='Service Offering', required=False)
    templatename = forms.ChoiceField(choices=PublicTemplates(), label='Template Name', required=False)
    zone = forms.ChoiceField(choices=Zones(), label='Zones', required=False)
    
    # Confiugre network


    assignip = forms.BooleanField(label='Assign a public IP', required=False)
    FWportfrom = forms.DecimalField(label='FW port from:', min_value=1,max_value=65000,decimal_places=0, required=False)
    FWportto = forms.DecimalField(label='FW port to:', min_value=1,max_value=65000,decimal_places=0,
        error_messages={'error': 'You cannot enter decimal places for a firewall port'}, required=False)

    # Create snapshot of root volume

    snaprootvol = forms.BooleanField(label='Snapshot root volume', required=False)
    createtempfromsnap = forms.BooleanField(label='Create template from root snapshot', required=False)
    deployvmfromsnap = forms.BooleanField(label='Deploy VM from template', required=False)

    # Data volume tests

    attachdatadatavol = forms.BooleanField(label='Attach data volume to VM', required=False)
    datavolserviceoffering = forms.ChoiceField(choices=DiskOfferings(), label='Select data volume size', required=False)
    createsnapfromdatavol = forms.BooleanField(label='Create snapshot from data volume', required=False)
    createtempfromdatavolsnap = forms.BooleanField(label='Create template from data volume snapshot', required=False)
    detachdatavol = forms.BooleanField(label='Detach data volume', required=False)
    extractdatavol = forms.BooleanField(label='Extract data volume', required=False)

    # ISO tests

    attachiso = forms.BooleanField(label='Attach an ISO', required=False)
    rebootvmwiso = forms.BooleanField(label='Reboot VM with ISO attached', required=False)
    stopstartvmwiso = forms.BooleanField(label='Stop and start VM with ISO attached', required=False)
    uploadiso = forms.BooleanField(label='Upload an ISO', required=False)
    pathtoiso = forms.URLField(required=False, label='Upload URL path for ISO')
    attachuploadediso = forms.BooleanField(label='Attach uploaded ISO', required=False)
    detachuploadediso = forms.BooleanField(label='Detach uploaded ISO', required=False)
    extractuploadediso = forms.BooleanField(label='Extract uploaded ISO', required=False)

    # Email test results

    email = forms.EmailField(label='Email when test completes', required=False)
  
