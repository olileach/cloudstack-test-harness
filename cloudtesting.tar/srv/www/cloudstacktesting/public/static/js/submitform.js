    $(document).ready(function() {

        // clean up of checkboxes when checkboxes are hidden after being displayed
        $('#id_snaprootvol').change(function() {
            if ($(this).not(':checked')){
                $('input[id=id_createtempfromsnap]').attr('checked', false);
                $('input[id=id_deployvmfromsnap]').attr('checked', false);
            }
        });

        $('#id_assignip').change(function() {
            if ($(this).not(':checked')){
                $('input[id=id_FWportfrom]').val('');
                $('input[id=id_FWportto]').val('');
            }
        });

        $('#id_createtempfromsnap').change(function() {
            if ($(this).not(':checked')){
                $('input[id=id_deployvmfromsnap]').attr('checked', false);
            }
        });

        $('#id_attachdatadatavol').change(function() {
            if ($(this).not(':checked')){
                $("#id_datavolserviceoffering").val("---------");
                $('input[id=id_createsnapfromdatavol]').attr('checked', false);
                $('input[id=id_createtempfromdatavolsnap]').attr('checked', false);
                $('input[id=id_detachdatavol]').attr('checked', false);
                $('input[id=id_extractdatavol]').attr('checked', false);
            }
        });

        $('#id_createsnapfromdatavol').change(function() {
            if ($(this).not(':checked')){
                $('input[id=id_createtempfromdatavolsnap]').attr('checked', false);
            }
        });

        $('#id_detachdatavol').change(function() {
            if ($(this).not(':checked')){
                $('input[id=id_extractdatavol]').attr('checked', false);
            }
        });    

        $('#id_attachiso').change(function() {
            if ($(this).not(':checked')){
                $('input[id=id_rebootvmwiso]').attr('checked', false);
                $('input[id=id_stopstartvmwiso]').attr('checked', false);
            }
        });

        $('#id_uploadiso').change(function() {
            if ($(this).not(':checked')){
        
                $('input[id=id_pathtoiso]').val('http://');
                $('input[id=id_attachuploadediso]').attr('checked', false);
                $('input[id=id_detachuploadediso]').attr('checked', false);
                $('input[id=id_extractuploadediso]').attr('checked', false);
            }
        });

        $('#id_attachuploadediso').change(function() {
            if ($(this).not(':checked')){

                $('input[id=id_detachuploadediso]').attr('checked', false);
                $('input[id=id_extractuploadediso]').attr('checked', false);
            }
        });

        $('#id_detachuploadediso').change(function() {
            if ($(this).not(':checked')){

                $('input[id=id_extractuploadediso]').attr('checked', false);
            }
        });











    });

    $(document).ready(function() {

        // hiding unrequired checkboxes when initial page loads  
        
        //network options
        $('#id_FWportto, #id_FWportfrom').hide();
        $("label[for='id_FWportfrom'], label[for='id_FWportto']").hide();
        
        //snapshot options
        $('#id_createtempfromsnap, #id_deployvmfromsnap').hide();
        $("label[for='id_createtempfromsnap'], label[for='id_deployvmfromsnap']").hide();

        //volume options
        $('#id_datavolserviceoffering, #id_createsnapfromdatavol, #id_createtempfromdatavolsnap, #id_detachdatavol, #id_extractdatavol').hide();
        $("label[for='id_datavolserviceoffering'], label[for='id_createsnapfromdatavol'], label[for='id_createtempfromdatavolsnap'], label[for='id_detachdatavol'], label[for='id_extractdatavol']").hide();

        //attach ISO options
        $('#id_rebootvmwiso').hide();
        $("label[for='id_rebootvmwiso']").hide();
        $('#id_stopstartvmwiso').hide();
        $("label[for='id_stopstartvmwiso']").hide();        


        $('#id_pathtoiso').hide();
        $("label[for='id_pathtoiso']").hide();
        $('#id_attachuploadediso').hide();
        $("label[for='id_attachuploadediso']").hide();
        $('#id_detachuploadediso').hide();
        $("label[for='id_detachuploadediso']").hide();
        $('#id_extractuploadediso').hide();
        $("label[for='id_extractuploadediso']").hide();

    });


    $(document).ready(function() {

        //network options
        $('#id_assignip').change(function() {
            if ($(this).is(':checked')){
                $('#id_FWportto, #id_FWportfrom').show();
                $("label[for='id_FWportfrom'], label[for='id_FWportto']").show();
            } else {
                $('#id_FWportto, #id_FWportfrom').hide();
                $("label[for='id_FWportfrom'], label[for='id_FWportto']").hide();
            }
        });

        //snapshot options
       $('#id_snaprootvol').change(function() {
          if ($('#id_snaprootvol').is(':checked')){
            
                $('#id_createtempfromsnap').show();
                $("label[for='id_createtempfromsnap']").show();
            
          } else { 

                $("label[for='id_createtempfromsnap']").hide();
                $('#id_createtempfromsnap').hide();
                $('#id_deployvmfromsnap').hide();
                $("label[for='id_deployvmfromsnap']").hide();
            }
        });

        $('#id_createtempfromsnap').change(function() {
            if ($(this).is(':checked')){
                                
                $('#id_deployvmfromsnap').show();
                $("label[for='id_deployvmfromsnap']").show();

            } else {
                
                $('#id_deployvmfromsnap').hide();
                $("label[for='id_deployvmfromsnap']").hide();

            }
        });

        //volume options
    
        $('#id_attachdatadatavol').change(function() {
            if ($(this).is(':checked')){
            
                $('#id_datavolserviceoffering').show();
                $("label[for='id_datavolserviceoffering']").show();
                $('#id_createsnapfromdatavol').show();
                $("label[for='id_createsnapfromdatavol']").show();
                $('#id_detachdatavol').show();
                $("label[for='id_detachdatavol']").show();
            
            } else {
            
                $('#id_datavolserviceoffering').hide();
                $("label[for='id_datavolserviceoffering']").hide();
                $('#id_createsnapfromdatavol').hide();
                $("label[for='id_createsnapfromdatavol']").hide();
                $('#id_createtempfromdatavolsnap').hide();
                $("label[for='id_createtempfromdatavolsnap']").hide();
                $('#id_detachdatavol').hide();
                $("label[for='id_detachdatavol']").hide();
                $('#id_extractdatavol').hide();
                $("label[for='id_extractdatavol']").hide();                
            
            }
        });


        $('#id_createsnapfromdatavol').change(function() {
            if ($(this).is(':checked')){

                $('#id_createtempfromdatavolsnap').show();
                $("label[for='id_createtempfromdatavolsnap']").show();
        
        } else {

                $('#id_createtempfromdatavolsnap').hide();
                $("label[for='id_createtempfromdatavolsnap']").hide();
            }

        });


        $('#id_detachdatavol').change(function() {
            if ($(this).is(':checked')){
                
                $('#id_extractdatavol').show();
                $("label[for='id_extractdatavol']").show();

            } else {

                $('#id_extractdatavol').hide();
                $("label[for='id_extractdatavol']").hide();

            }
        });


        $('#id_attachiso').change(function() {
            if ($(this).is(':checked')){
                
                $('#id_rebootvmwiso').show();
                $("label[for='id_rebootvmwiso']").show();
                $('#id_stopstartvmwiso').show();
                $("label[for='id_stopstartvmwiso']").show();

            } else {

                $('#id_rebootvmwiso').hide();
                $("label[for='id_rebootvmwiso']").hide();
                $('#id_stopstartvmwiso').hide();
                $("label[for='id_stopstartvmwiso']").hide();

            }
        });

        $('#id_uploadiso').change(function() {
            if ($(this).is(':checked')){

                $('#id_pathtoiso').show();
                $("label[for='id_pathtoiso']").show();
                $('#id_attachuploadediso').show();
                $("label[for='id_attachuploadediso']").show();

            } else {

                $('#id_pathtoiso').hide();
                $("label[for='id_pathtoiso']").hide();
                $('#id_attachuploadediso').hide();
                $("label[for='id_attachuploadediso']").hide();
                $('#id_detachuploadediso').hide();
                $("label[for='id_detachuploadediso']").hide();
                $('#id_extractuploadediso').hide();
                $("label[for='id_extractuploadediso']").hide();

            }
        });

        $('#id_attachuploadediso').change(function() {
            if ($(this).is(':checked')){

                $('#id_detachuploadediso').show();
                $("label[for='id_detachuploadediso']").show();

            } else {

                $('#id_detachuploadediso').hide();
                $("label[for='id_detachuploadediso']").hide();
                $('#id_extractuploadediso').hide();
                $("label[for='id_extractuploadediso']").hide();
            }
        });



        $('#id_detachuploadediso').change(function() {
            if ($(this).is(':checked')){

                $('#id_extractuploadediso').show();
                $("label[for='id_extractuploadediso']").show();

            } else {

                $('#id_extractuploadediso').hide();
                $("label[for='id_extractuploadediso']").hide();

            }
        });            



// Close function
    });