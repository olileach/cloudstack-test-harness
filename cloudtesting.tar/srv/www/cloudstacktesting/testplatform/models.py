from django.db import models

class CloudStackIpAddress(models.Model):
    name                = models.CharField(max_length=200)
    slug                = models.CharField(max_length=200)
  
    def __unicode__(self):
        return self.name

