from django.contrib import admin
from testplatform.models import CloudStackIpAddress

admin.site.register(CloudStackIpAddress)
